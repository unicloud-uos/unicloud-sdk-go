package all

import (
	"fmt"
	"github.com/unicloud-uos/unicloud-sdk-go/sdk/common"
	"testing"
)

func TestCollect(t *testing.T) {
	var ss *common.BillingSender = &common.BillingSender{
		Url: "https://api.unicloud.com",
		Path: "/networks/slb?Action=DescribeSlb&RegionId=HB1-BJMYB&Size=10&Page=1&AccessKeyId=MDlY64udfqxWbURz&Format=json&SignatureMethod=HMAC-SHA1&SignatureNonce=16343456325226&SignatureVersion=2.0&Timestamp=2021-03-10T15:17:00Z",
		AccessKey: "MDlY64udfqxWbURz",
		SecretKey: "BZ9G4Ldc9DtZ3riYCvfmf25J1pmh7g",
	}
	out := ss.SendGet()
	fmt.Print(out)
}
//
func TestDisks(t *testing.T) {
	var ss *common.BillingSender = &common.BillingSender{
		Url: "https://api.unicloud.com",
		Path: "/ebs?Action=DescribeDisks&RegionId=HB1-BJMYB&Version=2&Size=10&Page=1&AccessKeyId=MDlY64udfqxWbURz&Format=json&SignatureMethod=HMAC-SHA1&SignatureNonce=16343456325226&SignatureVersion=2.0&Timestamp=2021-03-10T15:17:00Z",
		AccessKey: "MDlY64udfqxWbURz",
		SecretKey: "BZ9G4Ldc9DtZ3riYCvfmf25J1pmh7g",
	}
	out := ss.SendGet()
	fmt.Print(out)
}

func TestCreateDisk(t *testing.T) {
	//var ss *common.BillingSender = &common.BillingSender{
	//	Url: "https://api.unicloud.com",
	//	//Path: "/ebs?Action=CreateDisk&RegionId=HB1-BJMYB&AzId=HB1-BJMY2&PayType=CHARGING_HOURS&SpecificationCode=ebs.highIO.ssd&Capacity=30&Quantity=1&Version=2&AccessKeyId=MDlY64udfqxWbURz&Format=json&SignatureMethod=HMAC-SHA1&SignatureNonce=16343456325226&SignatureVersion=2.0&Timestamp=2021-03-10T15:17:00Z",
	//	Path: "/ebs?Action=CreateDisk&RegionId=HB1-BJMYB&AzId=HB1-BJMY2&PayType=CHARGING_HOURS&SpecificationCode=ebs.highIO.ssd&Capacity=20&Quantity=1",
	//	AccessKey: "MDlY64udfqxWbURz",
	//	SecretKey: "BZ9G4Ldc9DtZ3riYCvfmf25J1pmh7g",
	//}
	//out, err := ss.SendGet()
	//if err != nil {
	//	t.Errorf("error : %+v", err)
	//} else {
	//	t.Logf("out : %+v", out)
	//}
}